# BLOOM — R3 COMPREHENSIVE BUILD SPEC: GRAPHIC DESIGNER REVIEW & COMPLETION APPENDIX

**ID:** VIS-R3-COMPLETION-2026-11-07-R1  
**Date:** 2026-11-07  
**Recipient:** Branding, Chief Architect, Structural UX, Codex/Developer, User Review  
**Publication target:** `/Bloom gut health/Agent Handoffs/`  
**Repository target:** `knagle-max/BloomGutHealth` / `enhance/bloom-experience` (NOT a claim of a commit)  
**Status:** **DESIGNER VISUAL VALUES PROVIDED; MASTER SPEC NOT YET FINAL/APPROVED.** One complete coordinated premium application is the end state; no interim owner review is required by the user's latest direction. Final user review occurs immediately before publishing to main. Engineering and specialist QA still occur throughout development.  
**Source documents:** `Bloom_Premium_Production_Master_Build_Spec_UX_Base_R3_2026-11-07.md` (168,580 bytes); `Bloom_Master_Build_Spec_R3_Designer_Architect_Package_2026-11-07.zip`; Designer v2.4 R2 asset ZIP; earlier R2 Architect, UX and Branding Continuity handoffs. This document only supplies DESIGNER-OWNED specifications and architectural conflict findings. It does not invent Branding copy or approve UX/Architect decisions.

## 1. Overall review verdict

**Comprehensive structural base: YES. Frozen, immediately executable, fully signed-off final spec: NOT YET.** R3 has seven complete 11-part screen contract sections, fixtures, element inventories, copy keys, mapping and source/claims constraints. It contains **729 literal `TO COMPLETE` occurrences** (including repeated template placeholders); those belonging to Branding, Architect, UX and Developer cannot be silently resolved by the Designer. The R3 transport ZIP includes **v2.3** assets, while the newer, previously published Designer delta is **v2.4** with mobile references, typography and corrected focus selector. The Architect must explicitly choose v2.4 as the visual source, verify the version/hash and prevent a v2.3 regression. Do not load two visual CSS files.

**Critical latest owner precedence:** the user's instruction for **no user reviews during implementation** supersedes older R2 proposals to stop after Today awaiting the owner's written GO. Developer may build Today first, capture/assess internally and continue all remaining views, with one consolidated **user review immediately before main**. The Chief Architect must record D2/D8 explicitly; keep QA regression and Specialist/Architect reviews during development. No main merge or production acceptance is implied.

**Source-verified vs proposed:** prior repository review observed `Dashboard.tsx`, `TodayFocus`, `CompanionHero`, `TodayFoodSummary`, `Explore`, `Progress`, `AthleteWorkspace`, `Profile`, `workspace.css`. Proposed visual selectors in this appendix are conditional on re-inventory at a **frozen SHA**. The designer has NOT inspected a live authenticated Render application or approved screenshots. All product values must be rendered from existing domain state; reference screenshots are synthetic art targets only.

## 2. Single-file design authority and precise material tokens

**CANONICAL ARTIFACT:** `styles/bloom-visual-scoped.css` from the attached R3 Designer Completion Asset ZIP. This is a **replacement evolution** of v2.4, not a second stylesheet. Developer copies only this version to `client/src/styles/bloom-visual-scoped.css` and imports it once after `workspace.css`. All selectors are contained beneath `.app-shell[data-bloom-visual="premium"]`. Turn on only by Architect-approved rollout flag. Unflagged appearance must be unchanged.

### Full token table (CSS variables, actual hex/values)

| Token | Everyday light | Everyday dark | Athlete | Role |
|---|---|---|---|---|
| `--bv-canvas` | `#F8F9F3` | `#101C17` | `#0F1B2E` | shell canvas |
| `--bv-paper` | `#F5F3EB` | `#192B24` | `#17263E` | editorial background |
| `--bv-porcelain` | `#FFFEFA` | `#22382E` | `#182B45` | surfaced material |
| `--bv-forest` | `#173E32` | `#EFF6EE` | `#F1F6FF` | main text |
| `--bv-forest-strong` | `#102B25` | `#FFFFFF` | `#FFFFFF` | emphasized text |
| `--bv-secondary` | `#52685C` | `#CADACF` | `#C3D4E9` | subtext, labels |
| `--bv-brand` | `#246B50` | `#A6DEBA` | `#81BEFF` | emphasis; NOT score |
| `--bv-sage / --bv-mist` | `#D9E7D5 / #EDF3EC` | `#345442 / #284434` | `#254967 / #203B63` | subtle panels |
| `--bv-clay / --bv-lilac` | `#D4A37C / #C9BDE3` | decorative only | decorative only | food/research **decoration**, not status text |
| `--bv-line` | `rgba(23,62,50,.11)` | `rgba(229,245,233,.17)` | `rgba(241,246,255,.16)` | 1px microborders |
| `--bv-shadow` | `0 12px 32px rgba(18,47,37,.065)` | `0 16px 35px rgba(0,0,0,.23)` | `0 16px 32px rgba(2,10,25,.28)` | one elevated surface max per cluster |
| `--bv-focus` | `#14543B` | `#A6DEBA` | `#81BEFF` | 3px accessible outline |
| `--bv-gradient` | `linear-gradient(135deg,#F5F3EB,#EDF3EC)` | `linear-gradient(135deg,#22382E,#29483A)` | `linear-gradient(135deg,#203B63,#0F1B2E)` | approved editorial slot only |

**Sampled contrast ratios (WCAG 2 luminance formula):** Forest `#173E32` on canvas `#F8F9F3` ≈11.2:1; secondary `#52685C` on porcelain `#FFFEFA` ≈5.96:1; brand `#246B50` on porcelain ≈6.32:1; dark text `#EFF6EE` on `#22382E` ≈11.4:1; Athlete cyan `#81BEFF` on navy ≈8.83:1. These do not prove contrast for every overlaid/translucent gradient or interaction state. For white text on the **light** brand green, use `#FFFFFF` (verify over actual filled button); for light/dark Athlete bright-accent button backgrounds use navy ink `#0F1B2E` for sufficient contrast. Do not use clay or lilac as small text.

### Typography (every heading from h1 through h3 and card titles)

| Element | Desktop CSS | ≤639px CSS | Color |
|---|---|---|---|
| h1 | 42px max / 48.7px line height / 600 / -0.03em; `clamp(30px,3.2vw,42px)` | 32px/37.4px, weight 600 | strong ink |
| h2 / editorial card title | `clamp(23px,1.9vw,30px)` / 1.23 / 550 / -0.018em | 24px/29.5px | ink |
| h3 / empty heading | 20px/26.4px / 600 / -0.012em | 19px/25px | ink |
| body | 16px/24px / 400 | 16px/24px | ink |
| supporting note | 14px/21px / 400 | 14px/21px | secondary |
| eyebrow | 12px/17px / 650 / 0.12em | same; wrap rather than clip | secondary |
| primary action label | 15px/21px / 650 | 15px/21px / 650 | contrast-adjusted action ink |
| numerals | 36px/40px / 600, tabular mono | 32px/38px / 600 | ink |
| chart tick / data label | 13px/18px mono; accessible alternative table | same; avoid collisions | secondary |

**Installed system fallback only:** editorial serif `"Iowan Old Style", Baskerville, "Palatino Linotype", Georgia, serif`; UI body `Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif`; numerals `ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace`. Do NOT fetch remotely, redistribute fonts or invent proprietary font licensing. Retain the real heading levels and DOM order. No artificial `font-synthesis` for scientific data is required.

### Structural geometry clarification

**Do not let art direction overwrite UX hierarchy.** Visual Designer can provide *paint geometry* (radii 14 controls / 20 inset / 26 surfaces / 28 hero / 32 editorial hero; material 1px; illustration maximums; typographic line length). The UX agent / Architect authorizes column count, source order, sidebars, breakpoints, CTA width and position, and sticky behavior. For a precise no-guess implementation, reuse the existing `workspace.css` geometry at frozen SHA unless the UX R3 structural table explicitly supplies different values; do NOT infer a 60/40 column layout from a mock. **Verified prior source baseline**: `.workspace-sidebar` width 224px, `.bloom-header-inner` height 76px, `.workspace-content` margin-left 224px, `.app-shell main` max-width 1160px, main padding 36px 40px 64px on wide screens. These are source-observed baselines, NOT approvals to change UX geometry. Requested new grid ratios remain `Architect/UX decision required` rather than Designer invention.

**Designer-owned spacing rhythm within existing slots:** surface interior padding 24px desktop / 20px mobile when no UX-specific padding exists; between textual title and caption 8px; within semantic metric row 12px; within *visual* panel groups 24px; major typographic sections 32px desktop / 24px mobile. These are styling defaults, not permission to reorder/move wrapper siblings or relocate a CTA. Apply only when component's existing accessible/UX contract does not already define spacing.

## 3. Definitive visual element styling by destination (attach to R3 sections 1–7)

| R3 section | Paint-only visual instructions; mapped to existing candidate selectors | Decorative asset / responsive rule | Flat treatment and evidence state |
|---|---|---|---|
| **1 Today** | `.dashboard-heading h1` editorial serif h1; `.today-focus-heading h2` editorial serif h2; `.today-focus-reason` 16/24 secondary; `.today-focus-actions` existing actions with 14px radii and min 44px; `.flagship-section-heading` h2 23–30px; `.flagship-recorded-energy` numeric mono; `.date-pill` and `.eyebrow` as neutral secondary; `.today-focus` background gradient, radius 28, shadow. **All selectors require branch verification.** | `botanical-orbit.svg` in approved empty decorative pocket of existing `.today-focus`, max 220px / 30% desktop, at mobile 110px and .07 opacity OR hidden if any conflict. `empty-journal.svg` only in confirmed empty journal. | `.flagship-macros` use baseline/dividers rather than per-nutrient cards, preserving unit labels and partial data; empty/partial/error text visible before illustration. No hero art behind actionable data. |
| **2 Food** | existing `FoodEntryChooser` / `LogMeal` / `NutritionHistory` material: porcelain editor, inset portion fields mist, 14px control radii, 16/24 food descriptions, 14/21 labels, tabular mono source-composition values; active review stage uses quiet paper inset and explicit unsaved text. | `ingredient-oats.svg` and `ingredient-berries.svg` in **pre-entry/confirmed-empty decorative slot only**, no illustration on top of active search, scanner, allergens, portion review or receipt; on mobile 104px max or hidden. | Use a single primary editor material, internal 1px dividers instead of stacked 26px panels for every ingredient. Do not flatten an editable/error/confirmation boundary that UX needs. |
| **3 Biology & Gut Reports** | `.biology-context`, `.biology-summary-tile` get warm anatomical atlas treatment: strong forest headings; measured values in mono; source tags secondary 14/21; scientific evidence drawer remains text-first, with the exact method/date. | `organism-concept.svg` and `molecular-educational.svg` only as abstract research decoration where source not misidentified; 160px max desktop / hidden at ≤639px if text/source competes. | Flatten subordinate decorative tiles using `.bv-flat-group` only where UX marks them safe; research relationships use dashed `4 4` lines *with text*. No false microbiome abundance rendering. |
| **4 Explore** | editorial concept headings and category markers; muted porcelain/mist surface with nonsemantic lilac wash; research pathway graphic strokes 2px, dashed if abstract; source text `bv-provenance` quiet and legible. | `molecular-educational.svg` in an approved decorative intro area only, 160px desktop / ≤104px mobile or hidden. | Replace excessive nested *visual* boundaries with whitespace + hairlines, keeping every evidence/source/study link and research disclaimer. |
| **5 Progress** | `.progress-workspace`, `FoodProgress.tsx`: measured stroke 2.5px round, 6px points + 2px porcelain outline, chart grid 1px soft, source ticks 13/18 mono; never add smooth splines or an inferred continuous area; only show an authorized completion ring with real denominator. | **No art behind data plots**. Optional `botanical-orbit.svg` in confirmed empty state only, 128px and .10 opacity; hide mobile if crowded. | Flat external plot stage with a clear exact-data details disclosure; remove second-order border/shadow only on UX-approved wrappers. Reference intervals and provenance stay visible. |
| **6 Athlete** | `.athlete-mode` palette from scoped variables: navy canvas `#0F1B2E`, raised `#182B45`, cyan `#81BEFF`, ink `#F1F6FF`; true numeric labels mono, clear record statuses (planned/completed/cancelled by words + noncolor symbol); retain source/provenance. | `athlete-motion.svg` in approved noninteractive workout-intro region, 170px max desktop, at ≤639px 104px or hidden. Never overlap sets/reps/fuel. | No fictional readiness/recovery metric; visually flatten repeated nested training summary panels but preserve editable set groups and save states. |
| **7 Profile** | `.science-heading h1` serif; `#profile-account`, `#nutrition-profile` and existing source/privacy details warm porcelain with separator hairlines; labels readable 14/21, forms 16/24, focus 3px; error/conflict distinct by text + 1px rose outline only in real error states. | **No mandatory illustration** (decision rather than invented asset). Optional `botanical-orbit.svg` only on verified noninteractive intro pocket, max 120px desktop; hide on mobile and when editing/consent active. | Explicitly do not flatten consent/revoke/delete confirmation or profile dirty/If-Match conflict boxes; aesthetic whitespace on noncritical settings groups only. |

**Responsive references already exist in v2.4:** `today-mobile.svg`, `food-mobile.svg`, `biology-mobile.svg`, `explore-mobile.svg`, `progress-mobile.svg`, `athlete-mobile.svg`, `profile-mobile.svg`; desktop originals present for Today/Food/Biology-Explore/Progress/Athlete/Profile. A conceptual reference is neither a source of DOM order nor evidence of a deployed UI. **Do not recreate those from scratch.** The R3 pack currently contains a nested v2.3 ZIP rather than the v2.4 art archive. Fix by replacing that embedded ZIP after Architect version approval and updating its SHA256SUMS, not by loading both.

## 4. Art safety table / technical flag

| Art | Source path | Approved mechanism requested | Screen safety |
|---|---|---|---|
| botanical orbit | `assets/botanical-orbit.svg` | `.bv-editorial-hero[data-bv-art="botanical-orbit"][data-bv-art-safe="true"]::after` | only with verified unused decorative zone; hide at zoom/collision |
| oats | `assets/ingredient-oats.svg` | same explicit art flag on Food intro, or one `<img alt="" aria-hidden="true">` if UX approves | not while reviewing meal |
| berries | `assets/ingredient-berries.svg` | Food first-use illustration only; explicit approved `img` if needed | food source/portion visible |
| conceptual organism | `assets/organism-concept.svg` | Biology selected *research* intro only | no real taxa implied |
| educational molecules | `assets/molecular-educational.svg` | Explore research intro only | do not imply validated measured molecule |
| athletic motion | `assets/athlete-motion.svg` | Athlete introductory art-only slot | no overlap workouts/numerics |
| journal empty | `assets/empty-journal.svg` | confirmed-empty illustration; not a loading/error/partial state | no false absence of eating |

**Exact art CSS safety contract:** `.app-shell[data-bloom-visual="premium"] .bv-editorial-hero[data-bv-art][data-bv-art-safe="true"]` activates noninteractive pseudo-element at right 1rem, top 50%, max width `min(30%,220px)`, opacity `.18`, pointer-events none, z-index 0; child content foreground z-index 1. At ≤639px max width 110px/opacity `.07`; at forced-colors disable art; at **200% zoom / cramped headings / error**, remove the attribute or hide the element, not a fact. The developer must capture the actual DOM/rects at 320, 390, 768, 1440 and zoom before setting the safety flag. If no verified text clearance, leave the slot disabled. Do not insert structural wrappers without UX approval.

**Critical implementation observation:** a pseudo-element with `z-index:0` does not by itself reserve textual room. For a permitted hero art, UX must approve either an existing, genuinely empty right-side pocket, or a purely decorative `<img>` placed in its already-owned optional illustration slot. **Do not add `padding-right` to the primary CTA container to make room** without UX/Architect approval. If art and text compete, hide art.

## 5. State paint matrix (all R3 fixture rows)

| State (existing UX source) | Visual-only treatment | Forbidden visual implication |
|---|---|---|
| loading | `.bv-state-loading`: soft mist–porcelain skeleton shimmer 1.6s linear; label remains real status, not decorative pseudo-content; reduced-motion makes static | don't show stale value as new |
| empty (confirmed successful source) | mist inset, optional empty-journal figure max 128px, readable first action | no “zero eaten” conclusion |
| partial / unknown | a 2px dashed brand under-rule **plus explicit text** `Partial` or `Unknown`, numeric tables keep `null` | never convert null to zero |
| error | porcelain + thin `#AD675B` border and required retry/status text | no red “poor health” indicator |
| review / unsaved | paper inset + 1px forest hairline, visible unsaved copy | not a successful save |
| saving | existing busy action + static/dynamic (reduced-motion) tiny inline activity indication; do not alter mutation semantics | not confirmed |
| confirmed saved | natural acknowledgement and `bv-save-confirmed` 260ms animation only after server receipt | no optimistic fake receipt |
| research / contradictory | research surface, dashed conceptual link and explicit limitations text | not a personal effect |
| conflict / revision | neutral surface with rose 1px boundary, visible correction options | no silent overwrite |
| revoked / disconnected | neutral muted connection appearance plus explicit disconnected text | no implied active data sync |
| planned Athlete | navy surface with neutral outlined status and text `Planned` | not performed work |
| completed Athlete | cyan point marker plus word `Completed` | only actual completed session |

## 6. Motion parameters (nonessential and bounded)

| Effect | Class / trigger | Duration / easing | Reduced-motion |
|---|---|---|---|
| Hero entrance | `.bv-hero-enter` on genuine first mount only | 280ms `cubic-bezier(.2,.8,.2,1)`, 5px vertical | none |
| Saved confirmation | `.bv-save-confirmed[data-save-state="confirmed"]` after server receipt | 260ms same ease, scale .992→1 | none; keep text |
| Chart reveal | `.bv-chart-ink[data-chart-ready="true"]` on newly loaded real series | 420ms same ease, fade only | none; underlying true data always present |
| Loading skeleton | `.bv-state-loading` when UX's source really loading | 1600ms linear background shimmer | static mist panel |

Never animate a scientifically meaningful data value to a fabricated intermediate number, autoplay infinite organ/organism motion, or announce persistence based on animation.

## 7. Mandatory acceptance decisions the Architect must close (non-Designer ownership)

| ID | Decision still required | Owner | Codex must NOT guess |
|---|---|---|---|
| A-01 | D1 frozen commit SHA, PR, preview and final asset source hashes | Architect/Developer | yes |
| A-02 | D2/D8 remove in-progress **owner checkpoint stop** per latest owner direction; final owner review before main only | Architect | yes |
| A-03 | D3 approve art slots and conditional markup with UX safety at 320/390/768/1440/200% | UX + Architect | yes |
| A-04 | D4 mobile bottom nav item count and existing mode routing; retain source current unless explicitly changed | UX + Architect | yes |
| A-05 | D5 approved copy keys and single-section quiet source wording; semantic checks | Branding + UX | yes |
| A-06 | D6 exact stylesheet import/cascade, current owner and long-lived flag/no-flag parity | Developer + Architect | yes |
| A-07 | D7 animation and empty-state art included in v0.6 premium milestone (approved aesthetic defaults in §6) | Architect | yes |
| A-08 | Verified actual app screenshots and independent visual pass after implementation before main | Developer + Designer + User Review + Architect | yes |

**Review timing clarification:** no user reviews needed during development as explicitly requested; developer should not block progress on owner's Today screenshot decision. Internal cross-agent visual QA after implementation is still required, and the final owner review immediately precedes publishing to main. Codex builds complete seven-destination premium milestone, not a sequence of public aesthetic patch releases.

## 8. Acceptance gate (what “pixel-perfect” means without faking evidence)

- Every *design-owned* color, type face/fallback, material, border, spacing, art scaling, state treatment and icon use is traceable to this Appendix or the canonical CSS asset; any divergence gets a numbered PR note and Designer disposition.
- Existing UX state/structure, the one truthful next action, and scientific provenance are preserved. The mockup is not a substitute for actual source-aware content or approved component hierarchy.
- Compare real after screenshots to design references at 390/1440 and also check 320/768, 200% zoom, keyboard, light/dark, Athlete, forced colors and reduced motion, including loading/empty/partial/review/error/confirmed/research states. Do not label references “AFTER ACTUAL APP”.
- **Do not self-certify visual completion from code/CI.** Designer verdict by route: VISUAL PASS / VISUAL FAIL / NOT VERIFIED; UX verdict separately, Architect accepts integration. Owner reviews the finished complete application before main.
- One premium build acceptance; no partial “premium finish” declared after Today.

## 9. Findings prioritized for the Brand/Architect combined master

| Finding | Severity | Required action |
|---|---|---|
| R3-01 729 `TO COMPLETE` occurrences; source calls itself UX BASE R3 | BLOCKS “final comprehensive” label | Branding, Architect and Developer fill their owned exact fields and resolve template duplicates before formally freezing final contract. This Designer Appendix fills **visual** design only. |
| R3-02 R3 transport ZIP embeds v2.3; v2.4 richer art/typography pack exists separately | HIGH | Architect selects canonical visual version and republishes corrected package/hash; no duplicate sheets. |
| R3-03 Older R2 owner Today GO vs user's latest final-review-only instruction | HIGH | Architect reconcile D2/D8 explicitly: internal Today QA, no user stop, final user review before main. |
| R3-04 Hard-coded layout grid and CTA placement cannot be chosen by Designer under lane contract | HIGH | UX supplies exact geometry or declares existing CSS geometry binding. Do not force mock screenshot grid. |
| R3-05 Art slots unverified in actual DOM | HIGH | Developer selector inventory + UX overlap testing before setting `data-bv-art-safe`. |
| R3-06 Screenshots and complete visual acceptance absent | FINAL RELEASE BLOCKER | capture true application across states/themes and submit for Designer/UX/User Review/Architect review before main. |
| R3-07 Typography, accent colors, states and visual paint originally incomplete | RESOLVED IN DESIGNER APPENDIX | use exact values/one CSS version; no CSS code improvisation. |

**Designer decision:** the premium art direction is approved for coordinated implementation **subject to exact integrated master source/version resolution**, not released as visually finished. This append-only completion document preserves the Brand/UX master intact while telling Codex precisely what is and is not authorized.
