# Bloom Premium Design — Production Styling Integration

**Status: Ready for developer integration and review; NOT a completed deployed visual experience.**

## The actual application audited
GitHub `knagle-max/BloomGutHealth`, branch `enhance/bloom-experience`. Source inspected: `client/src/workspace.css`, `client/src/index.css`, `client/src/App.tsx`, `client/src/pages/{Dashboard,Explore,Progress,AthleteWorkspace,Profile}.tsx`, and `design_guidelines.md`. No Render access: workspace selection is required. A live UI baseline and fixture screenshots were not available.

## Single canonical, genuinely opt-in visual stylesheet — v2.3 correction

**The two former stylesheets were competing and are retired. Import ONLY:** `styles/bloom-visual-scoped.css`.

1. Copy to `client/src/styles/bloom-visual-scoped.css`.
2. Import once **after** `workspace.css` from the existing entry point (verify the current import chain):

```ts
import "./workspace.css";
import "./styles/bloom-visual-scoped.css";
```

3. Add `data-bloom-visual="premium"` to the EXISTING `.app-shell` element ONLY after Architect/UX approval (example expression: `<div className={...} data-bloom-visual="premium">`). This is a style activation flag, **not** permission to change structure, route state, navigation or CTA positions. While the flag is absent, this CSS changes no elements, colors, or variables anywhere.
4. All theme variables are declared on the opted-in `.app-shell`; mode-specific values use `html.dark .app-shell[data-bloom-visual="premium"]` or `html[data-experience="athlete"] .app-shell[data-bloom-visual="premium"]`. There is NO `:root`, unscoped `.app-shell`, `html`, `body`, or global `.bv-*` selector in the file. Component aliases also require the opt-in ancestor.
5. **Never import** `bloom-premium-visual.css` or `bloom-production-skin.css` alongside this sheet; remove any prior imports. Only one canonical `--bv-*` token definition source exists within this corrected release.
6. Review UI slots with UX Agent, especially nav, controls, dark mode, disabled/review/error and scientific sources. Paint-only: typography size and decoration may change, but no DOM, route, CTA, progressive disclosure or control behavior edits are authorized.

### Mandatory regression checks
- With flag **absent**, baseline visual styles and `--bv-*` variables remain unchanged/undefined on the application root.
- With flag **present**, Today/Food/Biology/Progress/Athlete/Profile paint updates inside `.app-shell` only.
- Confirm light/dark and Athlete theme inheritance, existing priority of `client/src/workspace.css`, mobile 320–1440px, 200% zoom and WCAG AA.
- Enforce selector prefix in CI: EVERY qualified selector in this stylesheet must include `.app-shell[data-bloom-visual="premium"]` (including inside media queries).
- Verify no unscoped `:root`, `html`, `body`, `.bv-*`, `button`, or `.app-shell` selectors; no second visual CSS imported.

## Painting existing routes (no route refactor)
- `/` Dashboard/TodayFocus/TodayFoodSummary/TodayStatus: headline type, editorial background, one hero visual treatment; leave selection of first-meal action fully unchanged.
- `/log-meal` and `/nutrition`: style the existing food entry and nutrition journal, including source and missing-nutrient details; no save flow changes.
- `/explore` and `/precision`: illustrated contextual banners may sit only in existing non-interactive decorative regions; evidence drawers unchanged.
- `/progress`: measured points, axes and provenance styling only; underlying data/resampling unchanged.
- `/athlete`: navy + blue variables with intact logging and session states.
- `/profile`: warm neutral settings material; do not change private-data or destructive controls.

## Implementation components
The optional `SurfaceCard`, `EditorialHero`, and `TelemetryDisplay` wrappers must only substitute existing presentational wrappers (never become clickable wrappers around independent links). Recommended markup uses `className="bv-surface-card"` etc. Preserve heading levels, `role`, `aria-*`, and `data-testid`.

## Asset placement
Put the approved seven original SVGs under `client/public/brand/visual-v2/` or the app's existing public asset path and link them with absolute `/brand/visual-v2/foo.svg` URLs. The reference SVGs are **design targets only** and should live under `design/visual-system/references/`, not be used as route-level screenshots or page backgrounds. The legacy brand logo remains authoritative.

## Visual QA acceptance: not yet passed
Capture at 320,390,768,1440px widths, 200% zoom, light and dark Everyday and Athlete, six states: loading/empty/partial/error/review/research. Verify actual source-aware CTA, food review/save, full research references, chart unknown not zero, traceability, focus, reduced motion, 44px targets, contrast, colors-blind distinct data semantics, touch, and navigation. Compare screenshots against approved art while respecting UX layout.

## Known limits
This styling release does not include a running compiled Bloom app, GitHub commit, or a production visual acceptance signoff. GitHub write authorization was declined on a previous attempt. Render requires explicit workspace selection; no site has been reviewed.
