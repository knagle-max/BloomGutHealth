> **CSS correction v2.3:** Only `styles/bloom-visual-scoped.css` is supported. Former `bloom-premium-visual.css` and `bloom-production-skin.css` are retired. See `CSS_CONSOLIDATION_CORRECTION.md` and the updated `INTEGRATION_README.md`. Any import instructions below for earlier files are superseded.

# Bloom Premium Visual — Integration Addendum 02
Date: 2026-11-07 · Visual & Graphic Design Specialist · proposed for Chief Architect/UX/Branding review.

## Source of feedback
The user supplied integration feedback mentioning eight findings and a complete structural TSX with loading, empty, partial and error handling. **The full published handoff, its eight findings and TSX source were not attached in this turn**; do not claim these were independently evaluated or incorporated line-by-line. This addendum addresses only the gaps described in the user-provided excerpt.

## Preserved UX invariants
No modifications to navigation, primary CTA placement or source-aware action selection; meal review-before-save, scientific source provenance and accessible evidence-depth behavior remain UX/Developer-owned. None of these illustrated references are directives to change route layout or content hierarchy.

## New visual references
- `references/progress-desktop.svg/png`: tactile warm plot shell with measured observations, discrete original points, source/method treatment; synthetic values only, do not hardcode.
- `references/athlete-desktop.svg/png`: layered navy telemetry skin with restrained cyan trace, source and fueling treatments; no readiness score.
- `references/profile-desktop.svg/png`: warm preference/profile surfaces with botanical mark; existing privacy and consent controls preserved.
- `references/state-treatments-board.svg/png`: six visual treatments for loading/empty/partial/error/review/research, without inventing the UX states themselves.

## Exact paint-layer mappings
| Fixture | CSS visual treatment | Data/UX semantics preserved |
|---|---|---|
| Loading | `background:linear-gradient(110deg,#EDF3EC 8%,#F7FAF5 18%,#EDF3EC 33%);background-size:220% 100%` | `role=status`, no fabricated number, reduced-motion static |
| Empty | `#EDF3EC` inset material, botanical SVG opacity `.2`, text `#173E32` | Existing CTA and empty-state copy unchanged |
| Partial | `#FFFEFA` plus dotted `2px dashed #9BAFA2` annotation rule | Unknown is not zero; no green/yellow judgment |
| Error | `#FFFEFA` with `1px solid #AD675B`; icon + plain-language error | Existing retry and status semantics unchanged |
| Review | `#F5F3EB` + 1px `rgba(23,62,50,.11)` microborder | Source, amount, serving and save confirmation visible |
| Research | Deep forest `#173E32` + sage `#D9E7D5`; `stroke-dasharray:4 4` for associations | Evidence, study population, limitations and source drilldown |

Additive style classes `bv-state-loading`, `bv-state-empty`, `bv-state-partial`, `bv-state-error`, `bv-state-review`, `bv-state-research` may be applied **only** to existing UX-owned state slots. Do not change the state machine or status text.

## Design gate and acceptance
1. Branding + UX approves art references as *paint* guidance (not wireframe overrides).
2. Architect maps references to existing structurally approved components and release priorities.
3. Developer ensures loading, empty, partial, error, review and research fixtures have identical DOM and CTA behavior before/after styling.
4. Science signs off on any named organisms, molecules, reference intervals or biologically personalized imagery. All current vectors are conceptual/educational.
5. Render screenshot captures and full visual QA are **not done**; no final visual acceptance claimed.

## Delivery status
New 3 destinations + state board: source SVG and PNG files created in package. Existing three flagships remain. GitHub synchronization not claimed; prior attempt was blocked by write authorization.
