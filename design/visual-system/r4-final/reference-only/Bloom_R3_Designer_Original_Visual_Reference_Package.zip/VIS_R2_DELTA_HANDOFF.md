# Bloom — Graphic Designer R2 Premium Production Delta & Art Direction Handoff

**ID:** VIS-R2-DELTA-2026-11-07-R1  
**Date:** 2026-11-07 · **Role:** Lead Visual & Graphic Designer (visual lane only)  
**Recipient:** Branding (microcopy coordination), Structural UX (art-slot safety), Chief Architect (D1–D8 decision and approval), Codex/Developer (approved implementation), User Review (independent evaluation)  
**Canonical repository:** `knagle-max/BloomGutHealth` · target `enhance/bloom-experience` · **current implementation SHA not frozen/verified here**  
**Delivery status:** editable design delta and technical design package produced; shared Library publication separately verified; **not Architect-approved, not integrated, not deployed, not visually accepted**.  
**Supersession:** Extends approved v2.3 design foundation specifically for R2; replace its CSS only *after* Architect approval. Never load two designer stylesheets. This handoff does not supersede owner product/science/privacy decisions or Structural UX state/interaction contracts.

## 1. Production decision — one premium end state, with one owner checkpoint

I accept the owner's R2 order of work: Architect D1–D8 → parallel Branding voice and Designer v2.4 → UX safe-slot review → integrated Architect approval → Codex builds Today-only checkpoint → **owner GO/NO-GO** → remaining six destination groups → full screenshot matrix → Designer/User Review/UX/Architect/owner final review. The Today checkpoint is a **non-accepting directional gate**, not a release milestone. The *only* completion criterion is a coherent, fully implemented premium experience in **Today, Food, Biology + Gut Reports, Explore, Progress, Athlete, Profile**, including required states and mobile/dark variants. Codex may commit internal slices, but no interim app-wide premium signoff is permitted.

**Required inputs not yet present:** Architect D1–D8 written decisions, Branding route/state microcopy table and length limits, Structural UX art-slot PASS/FAIL, frozen code and deployment SHAs, actual before/after screenshots. Therefore every art slot and copy example below is **proposed pending those approvals**, not an instruction to relocate a CTA or alter DOM order.

## 2. Source audit & integrity

Reviewed (a) the R2 five-agent addendum supplied by the owner; (b) `Bloom_Premium_Production_Architect_Execution_Directive_2026-11-07.md`; (c) `Bloom_Premium_Production_Structural_UX_Code_Bridge_2026-11-07.md`; (d) `Bloom_Premium_Production_Visual_Gate_And_PR_Acceptance_2026-11-07.md`; (e) `Bloom_Branding_UX_CONTINUITY_v1.5_2026-11-07.md`; (f) the published original Designer v2.3 ZIP and relevant previously fetched source for `workspace.css`, `Dashboard.tsx`, `Explore.tsx`, `Progress.tsx`, `AthleteWorkspace.tsx`, `Profile.tsx`.

Verified v2.3 ZIP SHA-256: `da0c576e509058749c0029b70634b542dddd9a023c3f971f88d62636eecbdf5a` (matches supplied R2 value). **New package:** `Bloom_Premium_Visual_v2_4_R2_Designer_Delta.zip`, with `DELIVERY_MANIFEST.json` listing SHA-256 per file. The canonical stylesheet remains exactly `styles/bloom-visual-scoped.css`. **One CSS file only** in new archive. All SVGs pass XML parse, 21 editable reference/asset SVGs supplied; ZIP integrity and manifest hashes checked at creation. These validations do not establish browser rendering quality or compliance.

## 3. Design tokens, typescale, color application

### Fonts (no network dependency)
- Display serif: `"Iowan Old Style", Baskerville, "Palatino Linotype", Georgia, serif`; applies to `h1`, `h2`, `h3`, approved editorial card titles and empty-state headings. Use installed/system fallback, *not* remotely loaded fonts or redistributed font files. Preserve heading tag and DOM semantics from UX.
- Body: `Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif`, 16px/24px normal body, 14px minimum explanatory notes in existing app states.
- Scientific numerals: `ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace`, `font-variant-numeric:tabular-nums`, focus value 36/40 px (mobile 32/38 when necessary for width).
- Desktop display `clamp(30px,3.2vw,42px)`/1.16, h2 `clamp(23.2px,1.9vw,30px)`/1.23, h3 20/26.4, metadata 14/21. Mobile (≤639px) display 32/37.4, h2 24/29.5, h3 18.9/25. Titles may wrap without truncating actions.

Palette is inherited from the approved v2.3 variables, not a competing theme: Everyday ink `#173E32` on canvas `#F8F9F3`, brand green `#246B50`, paper `#F5F3EB`, sage `#D9E7D5`; Athlete base `#0F1B2E`, material `#182B45`, telemetry `#81BEFF`; Everyday dark text `#EFF6EE` on `#22382E`. R2 resolves unused accents: `--bv-clay:#D4A37C` is only a nonsemantic warm food illustration wash; `--bv-lilac:#C9BDE3` is only a nonsemantic research illustration wash. **Never use clay/lilac as body text over white** (approximate contrast 2.23:1 and 1.75:1). Verified sample foreground/background pairs via WCAG contrast formula: `#173E32/#F8F9F3` 11.20:1; `#52685C/#FFFEFA` 5.96:1; `#246B50/#FFFEFA` 6.32:1; `#EFF6EE/#22382E` 11.41:1; `#81BEFF/#0F1B2E` 8.83:1. These sampled pairs do not replace full color/state AA and transparency testing. Coach indigo `#62558D` is reserved by Branding; do not change it via this milestone without explicit approval.

## 4. Canonical CSS and exact focus-selector correction

**Single file:** `styles/bloom-visual-scoped.css`, imported once after `client/src/workspace.css`, within the approved flagged build. Retired `bloom-production-skin.css`, `bloom-premium-visual.css` and standalone theme variants are prohibited. Every qualified selector begins with `.app-shell[data-bloom-visual="premium"]`; `@keyframes` names are inert unless gated by those selector rules. The v2.3 nested focus bug is fixed in v2.4 to:

```css
.app-shell[data-bloom-visual="premium"] main :is(button, a, input, select, textarea, summary):focus-visible {
  outline:3px solid var(--bv-focus);
  outline-offset:3px;
}
```

The v2.3 `html.dark .app-shell...` and `html[data-experience="athlete"] .app-shell...` rules were rewritten as opt-in-prefixed selectors with ancestor tests through `:is(html.dark *)` and `:is(html[data-experience="athlete"] *)`. Browser validation of the ancestor selector, forced colors, keyboard focus and CSS cascade is still required. R2 classes do not assign action order, content priority or form behavior.

## 5. Proposed art-slot table — WAIT FOR ARCHITECT D3/D4 AND UX SIGNOFF

The `existing selector` column identifies **source-observed candidates**, not approved safe placement; Developer must re-verify against the frozen branch and actual DOM. Never assume `.today-focus` wraps the entire hero. Decoration is opt-in on **both** `data-bv-art` and `data-bv-art-safe="true"` on an existing UX-approved `bv-editorial-hero` wrapper. If no safe region exists, omit the art and return to UX/Architect for a single decorative `<img alt="" aria-hidden="true">` slot. No art may overlap primary action, methods, units, errors, source, disclosures or text at 200% zoom.

| Route | Source-observed candidate (not a placement guarantee) | Proposed SVG | Desktop treatment | 390/320px | Reserves / mode rules |
|---|---|---|---|---|---|
| Today `/` | `.daily-welcome`, `.today-focus`, `TodayFocus.tsx` | `botanical-orbit.svg` | Existing approved hero slot; max 220px/30%, right aligned, .18 opacity | 110px/7% or hidden if action/text collides | UX controls reservation, hide on dark/forced colors when interference; no CTA movement |
| Food `/log-meal`, `/nutrition` | `.bloom-panel` + components `FoodEntryChooser.tsx` / `LogMeal.tsx` | `ingredient-oats.svg`, `ingredient-berries.svg` | Only in verified unused illustration pocket, never inside active food review form | Hidden during review/keyboard entry or limited to empty-state pocket | Warm clay treatment; never obscures allergen/source/portion |
| Biology `/precision` & `/microbiome` | `.biology-context`, `.biology-summary-tile`; `PrecisionNutrition.tsx` / `Microbiome.tsx` | `organism-concept.svg`, `molecular-educational.svg` | Conceptual motif on a noninformational intro region | Hide if method/observation becomes crowded | Labels must say educational/schematic when shown as meaningful; not patient taxon data |
| Explore `/explore` | `Explore.tsx` (exact decorative container unverified) | `molecular-educational.svg` | Only approved noninteractive research category heading slot | 110px/7% or hidden | Lilac wash only for illustration field; no study relationship implied |
| Progress `/progress` | `.progress-workspace`, `FoodProgress.tsx` | None in measured plot; `botanical-orbit.svg` optional empty state | No art behind plot or axis, optional journal-empty section only | Empty state only | Preserve irregular dates, missingness, units, tables |
| Athlete `/athlete` | `AthleteWorkspace.tsx` (hero slot unverified) | `athlete-motion.svg` | Approved existing header/empty slot only | 110px/7% or hide | Athlete navy/blue, never overlays sets, planned status, fuel source |
| Profile `/profile` | `Profile.tsx` (safe region unverified) | `botanical-orbit.svg` or `empty-journal.svg` | Noninteractive profile introduction only | Hide if settings/consent content competes | Never cover consent controls, dirty draft or source revision conflicts |

**Implementation opt-in example (UX/Architect approved slot only):** existing `EditorialHero` wrapper may add `className="bv-editorial-hero" data-bv-art="botanical-orbit" data-bv-art-safe="true"`; the stylesheet uses a noninteractive `::after` background. This does **not** authorize changing element type, adding children, wrapping links, or moving any action. If an absolutely-positioned art image lacks an adequate reserved area at any breakpoint/zoom, remove `data-bv-art-safe` (hides art), report the failure, and request a safe slot. The decorative image class has `pointer-events:none`.

## 6. Motion and loading — all nonessential, 3 interactions maximum

| Paint effect | Trigger only after real UX state | Duration/ease | Reduced motion |
|---|---|---|---|
| Hero entrance `.bv-hero-enter` | Existing hero mounts, not every background refresh | 280ms `cubic-bezier(.2,.8,.2,1)`; 5px/opacity | No animation |
| Saved confirmation `.bv-save-confirmed[data-save-state="confirmed"]` | Persisted save receipt only, not optimistic request | 260ms same easing; subtle scale .992→1 | No animation |
| Chart appearance `.bv-chart-ink[data-chart-ready="true"]` | Actual valid observed series ready; opacity only, no synthetic drawn data | 420ms same easing | No animation |

Separately, `.bv-state-loading` uses a 1.6s skeleton shimmer (only on *actual* skeleton elements), static surface when reduced motion or forced colors. Never apply shimmer to stale records, controls, error, savings confirmation or health indicators. Developer/UX owns the state binding.

## 7. Flattening — exact targets, no structural removal by Designer

| View | Paint-only flatten candidate | What must not disappear |
|---|---|---|
| Today | Remove nested inner panel border/shadow within existing summary hierarchy; dividers instead | primary contextual CTA and report disclosures |
| Food | Flatten nested candidate/serving inset wrappers after UX review; retain source-aware review boundary | save/retry receipt, portions, unknown values |
| Biology | Reduce stacked borders inside explanatory context, retain clear provenance row | report identity, method, dates, studies |
| Explore | Flat topic labels and quiet separators instead of equal-weight borders | category search, evidence/limitations |
| Progress | Remove decorative card containers around chart internals; use one plotting surface, precise axes | tabs, data precision, missing spans, table |
| Athlete | Combine decorative chrome visually; retain true status/sets controls | planned/completed/cancelled, actual counts |
| Profile | Quiet inner separators between fields, fewer shadow layers | dirty conflict, consent, erasure, alert text |

Only apply `.bv-flat-group` to individually UX/Architect-approved existing wrappers. The Designer does not remove component nodes or accessibility semantics. Flattening in mock references is not authorization to refactor the live structure.

## 8. Updated editable targets

Inside the new ZIP, `references/food-mobile`, `progress-mobile`, `profile-mobile`, `biology-mobile`, `explore-mobile` and `athlete-mobile` are each supplied as SVG + PNG for 390×844 visual review. `progress-desktop` receives a flatter editorial reference and an explicit design-reference label. Existing desktop references, Today mobile, seven production-candidate original SVGs and state treatments remain in the package. All examples use illustrative information and are **DESIGN REFERENCES**, never actual application evidence. The R2 mobile reference's sample primary button and nav footer are visual-only placeholders; UX determines their text/position/action. These are style targets, not UX code contracts or evidence a mobile screen has been tested.

### Sidebar icon and mobile header glyph correction

**Production guidance:** preserve the existing logo asset and existing navigation semantics. In the live app, use approved 20px rounded-stroke icons from installed Lucide or original brand icons in the existing nav labels: line width 1.75px, stroke=currentColor, linecap/linejoin=round; no emoji and no replacement of destinations. Desktop reference icon refinements are not a mandate to replace UX nav. The **mobile header glyph** is shown as a neutral outlined 20px circle/cross motif in the new mobile targets; the actual app must retain its working menu/settings glyph and accessible label. A final reference-board icon pass remains conditional on D4 mobile navigation decision and Branding assets confirmation; do not invent a third nav structure.

## 9. Acceptance evidence / gate checklist

- **Architect:** post D1–D8 (especially D3 art safety, D4 chrome ownership/mobile nav, D7 animations, D8 owner checkpoint), freeze full branch/preview SHA, approve integrated contract and code mapping.
- **Branding:** deliver 60–90 state/route microcopy constants, single-section quiet provenance style and exact maximum string lengths; UX approves meaning, Designer checks fit at 320/390/1440 and 200% zoom. Until then all example text remains illustrative.
- **Structural UX:** PASS/FAIL per art slot at 320/390/768/1440, 200% zoom, keyboard; approve headline/empty and flatten surface slots without changing DOM/flows. Decide three vs five mobile destinations with Architect.
- **Developer:** import only the v2.4 single CSS after source freeze and approval; verify opt-in no-flag screenshot parity, class leakage, imported SVG hashes, source provenance, source-aware actions and full states; return screenshots and PR mapping.
- **Owner Today checkpoint:** BEFORE/AFTER actual app, 390 and 1440, light/dark/Athlete, first-use/recorded/partial/chosen action/failed source; written GO/NO-GO needed. Today is not a final visual acceptance.
- **Full final visual gate:** seven destinations, the QA-VIS-PRODUCTION matrix and cross-surface states; Designer per-view `VISUAL PASS/FAIL/NOT VERIFIED`, UX structural signoff, User Review independent evaluation, Architect final release decision. All seven must pass; a CSS build or sample gallery does not constitute an accepted premium product.

## 10. Known decisions/risks and exact disposition

| ID | Decision / risk | Severity | Status |
|---|---|---|---|
| VIS-R2-01 | Art placement requires reserved safe regions and D3 + UX approval | P0 | PROPOSED, not approved |
| VIS-R2-02 | Mobile nav 3 vs 5 / header art requires D4 | P0 | ARCHITECT DECISION |
| VIS-R2-03 | Brand-owned final text pending; visual copy length QA cannot close | P0 | BLOCKED ON BRANDING |
| VIS-R2-04 | Current deployed baseline/after screenshots at frozen SHA missing | P0 | NOT VERIFIED |
| VIS-R2-05 | Exact focus selector fixed in v2.4 CSS, browser validation pending | P0 | ASSET FIXED / INTEGRATION PENDING |
| VIS-R2-06 | Contrast sampled only, full theme/form/overlay AA audit pending | P0 | TEST NEEDED |
| VIS-R2-07 | CSS cascade conflicts with existing workspace.css unknown at deployment | P0 | DEVELOPER INVENTORY REQUIRED |
| VIS-R2-08 | Mobile design references added, but actual rendered comparison absent | P0 | ASSET PRODUCED / VISUAL NOT VERIFIED |
| VIS-R2-09 | One canonical stylesheet, source hash manifest, no-flag parity | P0 | STATIC VERIFIED / BROWSER PENDING |
| VIS-R2-10 | All seven destinations as one final accepted premium experience | P0 | REQUIREMENT FIXED / IMPLEMENTATION PENDING |

**Graphic Designer current signoff:** `DESIGN DELTA DELIVERED; APP VISUAL QUALITY NOT VERIFIED`. No claim of Architect D1–D8 signoff, live app review, GitHub branch commit, production deployment or owner GO. Shared Library publication is a coordination record only, not proof of direct agent receipt.
