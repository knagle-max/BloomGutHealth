> **CSS correction v2.3:** Only `styles/bloom-visual-scoped.css` is supported. Former `bloom-premium-visual.css` and `bloom-production-skin.css` are retired. See `CSS_CONSOLIDATION_CORRECTION.md` and the updated `INTEGRATION_README.md`. Any import instructions below for earlier files are superseded.

# Bloom Premium Visual Design — Specialist Delivery v2.0
Date: 2026-11-07 | Owner: Visual & Graphic Design | Target: `enhance/bloom-experience`
Status: **DELIVERED DESIGN ARTIFACTS, NOT IMPLEMENTED OR APPROVED UI**.

## Authority & lane
UX Agent owns information architecture, UI skeleton, order, primary actions, route positions and progressive disclosure. Chief Architect approves integration. Developer/Codex owns implementation/tests. Branding owns identity approval; Biology owns accuracy of biological claims. This package must **not** be interpreted as a change request to interaction behavior or DOM order. The screen references are *aesthetic/illustrative compositions*, not canonical wireframes; when they conflict with UX contracts, preserve the UX contracts and map these materials to existing slots.

## Reviewed sources
Existing brand zip (2026-10-18), brand concept image, brand icon/wordmark SVGs, original proposed brand tokens, `SCREEN_BLUEPRINTS.md`, Biology specialist handoff, branch `README.md`, `design_guidelines.md`, and `client/src/App.tsx`/`index.css` inspected 2026-11-07 via GitHub. Current Render interface **not rendered/visually inspected**: connected Render requires user selection of workspace. Therefore no claims are made about the *current screen appearance* or deployed comparison.

## Design targets (illustrations only)
- `references/today-desktop.svg` and `.png`: botanical daily-focus atmospheric composition, warm-paper material, asymmetric visual emphasis. First-run illustrative empty state; one contextual primary action. The design uses synthetic copy and is not a screenshot.
- `references/food-desktop.svg` and `.png`: editorial ingredient bowl study, provenance-based detail panel. Meal is unsaved illustrative content; deliberately uses `Unknown` nutrient cells.
- `references/biology-explore-desktop.svg` and `.png`: purposeful illustrated organism atlas, dashed association routes; explanatory research state is explicitly *not a personal measurement*.
- `references/today-mobile.svg` and `.png`: mobile styling demonstration at 390×844; **do not copy the drawing's navigation placement or input order** over UX implementation.
Source SVGs are the high-resolution editable originals; PNGs are raster preview exports. Captions and illustrative text should be replaced by actual app data and UX-approved copy.

## Asset manifest
All assets are original lightweight editable SVGs with predictable `viewBox=0 0 256 256`: `botanical-orbit` (atmospheric), `ingredient-oats`, `ingredient-berries` (food illustrations), `organism-concept` (fictional educational microbe—NOT a species-level diagram), `molecular-educational` (a labeled schematic—not a chemically accurate structure), `athlete-motion` (motion symbol), `empty-journal` (empty-state decorative art). Existing brand logos MUST remain from approved brand delivery; these graphics never replace the brandmark. SVGs are illustration assets, not aria controls; decorative instance = `alt=""` / `aria-hidden="true"`; meaningful instance = explicit nearby descriptive text. Do not use organism glyph to represent an actual diagnosed taxon.

## Exact styling contract
CSS: `styles/bloom-premium-visual.css` — import AFTER existing `client/src/workspace.css`, as an opt-in class layer. No global `body`, `.app-shell`, `.workspace-content`, button, nav, selector or route overrides. Paint primitives:
- `<SurfaceCard>`: class `bv-surface-card` or `data-depth="inset"` with warm ivory surface, alpha forest hairline, 28px radius, ambient 12/32 shadow. Developer must keep existing padding/structure.
- `<EditorialHero>`: class `bv-editorial-hero` and `bv-editorial-title` within EXISTING approved hero placement. Cream-to-sage gradient. Optional decorative overlay must not obscure text and controls.
- `<TelemetryDisplay>`: `bv-telemetry`, `.bv-telemetry-value`, `.bv-telemetry-unit`. Monospace tabular values, 36/40 focal numeral and measured/estimated labels supplied by data model. Athlete selects blue/navy via existing `[data-experience=athlete]`.
- SVG chart paint: `.bv-chart-line` 2.5px solid, `.bv-chart-axis` 1px, `.bv-chart-point` 6px diameter, `.bv-chart-inferred` dashed 4 4 with semantic legend. Undefined values break paths and are never treated as zero; no cubic smoothing on samples that would misstate data. Track progress rings only for existing validated completion denominators, 112px circle and 8px stroke.
- Light everyday: `#F8F9F3` canvas; `#FFFEFA` porcelain; `#173E32` ink; `#246B50` action; `#EDF3EC` inset; `#D9E7D5` sage; `#D4A37C` clay.
- Everyday dark: `#101C17` canvas, `#22382E` surface, `#EFF6EE` copy, `#9DD9B0` chart line.
- Athlete: `#0F1B2E` canvas, `#182B45` material, `#81BEFF` chart line, `#F1F6FF` text. No competitive-good/bad color coding.
- Typography: Inter body 16/24; Georgia/approved editorial face ONLY on existing prominent title slots; `clamp(28px,3.6vw,48px)` / 1.12 title style; micro technical labels at 13px minimum and only with sufficient contrast; body annotations 14px+; input body 16px+.
- Gradients: everyday 135deg `#F5F3EB → #EDF3EC`; everyday chart 180deg `rgba(36,107,80,.24) → transparent`; Athlete 135deg `#203B63 → #0F1B2E`, chart `rgba(129,190,255,.26) → transparent`.

## Specific institutional legacy signatures to replace, *if still visible in rendered app*
Repository `client/src/index.css` contains neutral sidebar variables `--sidebar:220 6% 96%`, `--sidebar-border:220 8% 90%`, generic shadow presets, and legacy `--health-excellent/--health-good/--health-attention` variables. These are **source-level observations**, not confirmed current runtime screenshots. Use stronger brand surfaces and editorial typography in approved slots; remove or stop referencing legacy *unvalidated* health-score aesthetics only with science/developer approval. Prior `design_guidelines.md` explicitly forbids global arbitrary health scores. Generic gridded cards, flat lines, and repeated gray controls should be compared against actual deployed pixels before replacing—do not presume their presence.

## Integration sequence / no structural deviations
1. Architect/UX/Branding review these designs against flagship UX Blueprint and existing brand-transfer receipt.
2. Developer inventories currently rendered selectors. Import CSS opt-in, NOT broad overrides. Replace instance styling only on the UX-owned structural elements. Preserve DOM order, route boundaries, CTA positions/labels/handler, food entry review-before-save, evidence disclosure, error/empty state and science provenance.
3. Import selected SVGs to existing brand/public assets pipeline with optimization (svgo preserving viewBox, sanitize XML, fixed palettes or currentColor per icon). Screenshots SVGs are REFERENCES, not production assets.
4. Use image components `loading="lazy" decoding="async"` on noncritical illustrations; never lazy load active primary-control labels. Decorative images have alt="". Avoid expensive backdrop blurs across scrollable areas.
5. Regression screenshots 320/390/768/1440px, Everyday light/dark and Athlete light/dark, 200% zoom, forced-colors, keyboard navigation, reduced-motion. Test source/unknown units, missingness, chart focus, and partial nutrition data. Compare to approved target screenshot and existing layout coordinates. 
6. Capture side-by-side before/after from same live routes and fixture data. Biology approves any imagery linked to a named species/reaction before release. Do not mark complete based on presence of images or CSS alone.

## Status matrix
- VIZ-PREMIUM-01: Three flagship editable compositions + mobile Today illustration — **asset files produced; architecture/UX review pending**.
- VIZ-PREMIUM-02: Seven original illustration motifs — **asset files produced; asset QA pending**.
- VIZ-PREMIUM-03: Theme variants and CSS chart primitives — **CSS delivered; implementation pending**.
- VIZ-PREMIUM-04: Scientific honesty and source-aware chart grammar — **spec delivered; Biology approval pending**.
- VIZ-PREMIUM-05: Render baseline and actual before/after — **BLOCKED: Render workspace not selected; not completed**.
- VIZ-PREMIUM-06: Deployed application comparison and visual acceptance — **NOT STARTED; dependent on Developer implementation**.
