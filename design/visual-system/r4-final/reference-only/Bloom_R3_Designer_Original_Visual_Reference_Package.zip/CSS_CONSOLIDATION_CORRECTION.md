# Bloom Visual CSS consolidation — correction v2.3

**Findings resolved in package:** (1) two competing CSS files; (2) global selectors misidentified as opt-in.

**Change:** Removed both `styles/bloom-premium-visual.css` and `styles/bloom-production-skin.css`. The single canonical visual stylesheet is `styles/bloom-visual-scoped.css`.

**Opt-in contract:** All selector rules, including CSS variables and media-query rules, are descendants of or directly match `.app-shell[data-bloom-visual="premium"]`. Existing Bloom root, navigation, header, routes and UX behavior are NOT affected until the existing app shell receives this attribute after approval. Styles never apply to login/signup screens outside `.app-shell`.

**CSS token ownership:** One `--bv-*` family source. Retain authoritative existing CSS tokens from `workspace.css`; `--bv-*` are optional paint aliases and do not overwrite them. Light/dark/Athlete overrides are scoped under the single activation flag. No `:root` declarations.

**Visual signoff:** CSS parse & selector scoping validation passed offline; live application and visual acceptance remain unverified. Build, browser, accessibility and UX review must be performed by Developer/Architect on an authorized deployment.

**Supersession:** All previous instructions saying the global `bloom-production-skin.css` is opt-in or recommending simultaneous import of both files are withdrawn. `INTEGRATION_README.md` in this release is authoritative.
